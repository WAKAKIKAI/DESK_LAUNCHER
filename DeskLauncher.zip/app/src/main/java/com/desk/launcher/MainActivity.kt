package com.desk.launcher
import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity(), SensorEventListener {
    private var crashed = false
    private lateinit var gl: GLSurfaceView
    private lateinit var r: DeskRenderer
    private lateinit var term: LinearLayout
    private lateinit var out: TextView
    private lateinit var inp: EditText
    private lateinit var sv: ScrollView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val crashF = java.io.File(filesDir, "crash.txt")
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashF.writeText(t.name + "\n" + android.util.Log.getStackTraceString(e)) } catch (x: Exception) {}
            android.os.Process.killProcess(android.os.Process.myPid()); System.exit(1) }
        if (crashF.exists()) {
            val tv = TextView(this).apply { text = "CRASH REPORT - screenshot this:\n\n" + crashF.readText().take(2800); setTextColor(-1); setBackgroundColor(-16777216); textSize = 11f; setPadding(30, 100, 30, 30) }
            crashF.delete(); crashed = true; setContentView(ScrollView(this).apply { addView(tv) }); return
        }
        if (Build.VERSION.SDK_INT >= 28) { val a = window.attributes; a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; window.attributes = a }
        r = DeskRenderer(this)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(3); setRenderer(r); preserveEGLContextOnPause = true }
        gl.setOnTouchListener { _, e ->
            if (term.visibility == View.VISIBLE) return@setOnTouchListener false
            val a = e.actionMasked; val x = e.x; val y = e.y; val t = e.eventTime
            gl.queueEvent { r.touch(a, x, y, t) }; true
        }
        setContentView(gl)
        try {
        if (Build.VERSION.SDK_INT >= 30) { window.setDecorFitsSystemWindows(false); window.insetsController?.hide(WindowInsets.Type.systemBars()) }
        else window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        } catch (e: Throwable) {}
        val green = 0xFF5DFF8A.toInt()
        out = TextView(this).apply { setTextColor(green); typeface = Typeface.MONOSPACE; textSize = 13f; setShadowLayer(8f, 0f, 0f, green) }
        inp = EditText(this).apply { setTextColor(green); typeface = Typeface.MONOSPACE; textSize = 14f; background = null; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE; hint = "> type help"; setHintTextColor(0x665DFF8A) }
        sv = ScrollView(this).apply { addView(out) }
        term = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(44, 90, 44, 40); visibility = View.GONE
            background = GradientDrawable().apply { setColor(0xF4031A09.toInt()); cornerRadius = 70f; setStroke(16, 0xFF2A2118.toInt()) }
            addView(sv, LinearLayout.LayoutParams(-1, 0, 1f)); addView(inp)
        }
        addContentView(term, FrameLayout.LayoutParams(-1, -1).apply { setMargins(36, 160, 36, 160) })
        inp.setOnEditorActionListener { v, _, _ ->
            val line = v.text.toString().trim(); v.text = ""; out.append("> " + line + "\n")
            when (line) { "exit" -> closeTerm(); "clear" -> out.text = ""
                else -> if (line.isNotEmpty()) gl.queueEvent { r.cmd(line) { res -> runOnUiThread { out.append(res + "\n"); sv.fullScroll(View.FOCUS_DOWN) } } } }
            true
        }
    }
    fun openTerm() { term.visibility = View.VISIBLE; if (out.text.isEmpty()) out.text = "DESK-OS 1.0  (type help, exit)\n"; inp.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(inp, 0) }
    private fun closeTerm() { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(inp.windowToken, 0); term.visibility = View.GONE }
    override fun onResume() {
        super.onResume(); if (crashed) return; gl.onResume(); r.resumeSfx()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
    }
    override fun onPause() { super.onPause(); if (crashed) return; gl.onPause(); r.pauseSfx(); (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this) }
    override fun onSensorChanged(e: SensorEvent) { r.tiltX = -e.values[0] / 9.8f * 0.35f; r.tiltZ = (e.values[1] - 7f) / 9.8f * 0.3f }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    @Deprecated("launcher") override fun onBackPressed() { if (!crashed && term.visibility == View.VISIBLE) closeTerm() }
}
