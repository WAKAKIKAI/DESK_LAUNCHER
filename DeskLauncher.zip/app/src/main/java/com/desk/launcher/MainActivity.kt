package com.desk.launcher
import android.app.Activity
import android.content.Context
import android.hardware.*
import android.opengl.GLSurfaceView
import android.os.Bundle

class MainActivity : Activity(), SensorEventListener {
    private lateinit var gl: GLSurfaceView
    private lateinit var r: DeskRenderer
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        r = DeskRenderer(this)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(3); setRenderer(r); preserveEGLContextOnPause = true }
        gl.setOnTouchListener { _, e ->
            val a = e.actionMasked; val x = e.x; val y = e.y; val t = e.eventTime
            gl.queueEvent { r.touch(a, x, y, t) }; true
        }
        setContentView(gl)
    }
    override fun onResume() {
        super.onResume(); gl.onResume()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
    }
    override fun onPause() { super.onPause(); gl.onPause(); (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this) }
    override fun onSensorChanged(e: SensorEvent) { r.tiltX = -e.values[0] / 9.8f * 0.35f; r.tiltZ = (e.values[1] - 7f) / 9.8f * 0.3f }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    @Deprecated("launcher ignores back") override fun onBackPressed() {}
}
