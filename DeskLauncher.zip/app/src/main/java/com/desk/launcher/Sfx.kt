package com.desk.launcher
import android.media.*
import java.util.Random
import kotlin.math.*

class Sfx {
    private val SR = 22050
    private val rnd = Random(5)
    private val TAU = 6.2831853f
    @Volatile private var musicA: AudioTrack? = null
    @Volatile private var musicB: AudioTrack? = null
    @Volatile private var cur = -1
    private fun n() = rnd.nextFloat() * 2 - 1
    private fun gen(sec: Float, f: (Float) -> Float) = ShortArray((sec * SR).toInt()) { (f(it / SR.toFloat()).coerceIn(-1f, 1f) * 28000).toInt().toShort() }
    private fun mk(d: ShortArray, loop: Boolean, vol: Float): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(d.size * 2).build()
        t.write(d, 0, d.size); if (loop) t.setLoopPoints(0, d.size, -1); t.setVolume(vol); return t
    }
    private val rustleT: AudioTrack; private val splashT: AudioTrack; private val burnT: AudioTrack; private val clickT: AudioTrack; private val fireT: AudioTrack
    init {
        var lp = 0f; var pop = 0f
        rustleT = mk(gen(.3f) { t -> val x = n(); lp += (x - lp) * .3f; (x - lp) * sin(3.14159f * t / .3f).pow(2) * (.4f + .6f * abs(sin(t * 80f))) * 1.4f }, false, .7f)
        splashT = mk(gen(.9f) { t -> val x = n(); lp += (x - lp) * (.04f + .5f * exp(-t * 6f)); var o = lp * exp(-t * 4f) * 2.2f
            for (b in 0..3) { val tb = t - .04f - b * .07f; if (tb > 0) o += sin(TAU * (380f + b * 180f + 2200f * tb) * tb) * exp(-tb * 25f) * .25f }; o }, false, .9f)
        burnT = mk(gen(1.4f) { t -> val x = n(); lp += (x - lp) * .08f; if (rnd.nextFloat() < .003f) pop = rnd.nextFloat(); pop *= .992f
            lp * min(1f, t * 8f) * exp(-t * 1.6f) * 2.5f + n() * pop * .5f }, false, .9f)
        clickT = mk(gen(.05f) { t -> sin(TAU * 1800f * t) * exp(-t * 110f) }, false, .5f)
        fireT = mk(gen(2f) { _ -> lp += (n() - lp) * .03f; if (rnd.nextFloat() < .0012f) pop = rnd.nextFloat(); pop *= .994f; lp * .5f + n() * pop * .6f }, true, .12f)
        fireT.play()
        Thread {
            val a = mk(music(arrayOf(intArrayOf(50, 53, 57, 60), intArrayOf(46, 50, 53, 57), intArrayOf(48, 52, 55, 59), intArrayOf(45, 49, 52, 55)), .75f, 1), true, .55f)
            val b = mk(music(arrayOf(intArrayOf(48, 55, 59, 62), intArrayOf(45, 52, 57, 60), intArrayOf(50, 57, 60, 65), intArrayOf(43, 50, 55, 58)), .55f, 2), true, .5f)
            musicA = a; musicB = b; setMusic(cur)
        }.start()
    }
    private fun music(ch: Array<IntArray>, beat: Float, seed: Long): ShortArray {
        val r = Random(seed); val d = beat * 2; val seq = IntArray(ch.size * 8) { r.nextInt(5) }; val pent = intArrayOf(0, 3, 5, 7, 10); var cr = 0f
        return gen(d * ch.size) { t ->
            val c = ch[(t / d).toInt() % ch.size]; val tc = t % d; var o = 0f
            for (m in c) { val f = 440f * 2f.pow((m - 69) / 12f); val e = min(1f, tc * 6f) * exp(-tc * .7f)
                o += (sin(TAU * f * t) + .3f * sin(2 * TAU * f * t) + .1f * sin(3 * TAU * f * t)) * e * .1f }
            val st = (t / (beat / 2)).toInt(); val tt = t % (beat / 2)
            if (seq[st % seq.size] > 0 || st % 2 == 0) { val f = 440f * 2f.pow((c[0] + 24 + pent[seq[st % seq.size]] - 69) / 12f); o += sin(TAU * f * t) * exp(-tt * 7f) * min(1f, tt * 80f) * .18f }
            if (rnd.nextFloat() < .0004f) cr = rnd.nextFloat() * .5f; cr *= .97f
            o + n() * cr * .3f }
    }
    private fun shot(t: AudioTrack) { try { t.stop(); t.reloadStaticData(); t.play() } catch (e: Exception) {} }
    fun rustle(v: Float) { rustleT.setVolume(.2f + .6f * v.coerceIn(0f, 1f)); shot(rustleT) }
    fun splash() = shot(splashT)
    fun burn() = shot(burnT)
    fun click() = shot(clickT)
    fun setMusic(i: Int) { cur = i; musicA?.pause(); musicB?.pause(); if (i == 0) musicA?.play() else if (i == 1) musicB?.play() }
    fun pause() { fireT.pause(); musicA?.pause(); musicB?.pause() }
    fun resume() { fireT.play(); if (cur == 0) musicA?.play() else if (cur == 1) musicB?.play() }
}
