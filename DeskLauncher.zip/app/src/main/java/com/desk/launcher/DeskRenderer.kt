package com.desk.launcher
import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.opengl.*
import java.nio.*
import java.util.Calendar
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

const val NX = 10; const val NY = 14; const val NV = (NX + 1) * (NY + 1)
const val PW = 0.6f; const val PH = 0.8f
class Page(val pkg: String, val tex: Int) {
    var x = 0f; var z = 0f; var rot = 0f; var vx = 0f; var vz = 0f; var pvx = 0f; var pvz = 0f
    var ax = 0f; var az = 0f; var lift = 0f; var gu = 0f; var gv = 0f
    val off = FloatArray(NV * 3); val vel = FloatArray(NV * 3)
}

private const val COMMON = """#version 300 es
precision highp float;
uniform vec4 uSun; uniform vec3 uSunCol; uniform vec3 uAmb; uniform vec3 uEye; uniform vec2 uRes;
float h21(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float sunMask(vec2 p){vec2 q=p-uSun.xy;q.x+=q.y*.35;vec2 d=abs(q)-vec2(.8,.95);
 float e=1.-smoothstep(-.02,.07,max(d.x,d.y));
 float b=smoothstep(.012,.03,abs(q.x))*smoothstep(.012,.03,abs(q.y-.08));return e*b*uSun.z;}
vec3 lampPool(vec2 p){vec2 d=p-vec2(1.,-1.6);return vec3(1.,.6,.3)*exp(-dot(d,d)*1.1)*(.12+.9*(1.-uSun.z));}
"""
private const val VS_DESK = """#version 300 es
layout(location=0) in vec3 aP; uniform mat4 uVP; out vec3 vW;
void main(){vW=aP;gl_Position=uVP*vec4(aP,1.);}"""
private const val FS_DESK = """
in vec3 vW; out vec4 o;
float grain(vec2 p){float pl=floor(p.y/.55);vec2 q=vec2(p.x*.9+pl*7.3,p.y*14.);
 float n=vn(q)*.6+vn(q*vec2(2.3,2.)+3.)*.3+vn(q*vec2(6.,5.))*.1;
 return mix(n,.5+.5*sin(p.y*22.+n*9.+pl*3.),.55);}
void main(){vec2 p=vW.xz;float g=grain(p);float pl=floor(p.y/.55);float f=fract(p.y/.55);
 vec3 al=mix(vec3(.15,.085,.05),vec3(.38,.21,.11),g)*(.8+.35*h21(vec2(pl,3.)));
 al*=mix(.4,1.,smoothstep(0.,.014,f)*smoothstep(0.,.014,1.-f));
 float r=length(p-vec2(-.85,1.1));al*=1.-.4*smoothstep(.2,.206,r)*(1.-smoothstep(.206,.23,r))*(.6+.4*vn(p*30.));
 vec3 n=normalize(vec3(-(grain(p+vec2(.004,0.))-g)*2.5,1.,-(grain(p+vec2(0.,.004))-g)*2.5));
 vec3 L=normalize(vec3(uSun.x*.2,.8,-.55));vec3 V=normalize(uEye-vW);float m=sunMask(p);
 vec3 c=al*(uAmb+uSunCol*m*max(dot(n,L),0.)+lampPool(p));
 c+=uSunCol*m*pow(max(dot(n,normalize(L+V)),0.),40.)*.35*(.4+g);
 vec2 sc=gl_FragCoord.xy/uRes-.5;c*=1.-dot(sc,sc)*1.4;
 o=vec4(1.-exp(-c*1.5),1.);}"""
private const val VS_PAGE = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec2 aUV; layout(location=2) in vec3 aN;
uniform mat4 uVP; out vec3 vW; out vec2 vUV; out vec3 vN;
void main(){vW=aP;vUV=aUV;vN=aN;gl_Position=uVP*vec4(aP,1.);}"""
private const val FS_PAGE = """
uniform sampler2D uTex; in vec3 vW; in vec2 vUV; in vec3 vN; out vec4 o;
void main(){vec4 t=texture(uTex,vUV);vec3 n=normalize(vN);vec3 L=normalize(vec3(uSun.x*.2,.8,-.55));
 float m=sunMask(vW.xz);float nl=dot(n,L);
 float fib=.96+.08*vn(vW.xz*260.)*vn(vW.xz*90.+7.);
 vec3 li=uAmb*(.65+.35*n.y)+uSunCol*m*(max(nl,0.)+max(-nl,0.)*.35)+lampPool(vW.xz);
 o=vec4(1.-exp(-t.rgb*li*fib*1.5),t.a);}"""
private const val VS_SH = """#version 300 es
layout(location=0) in vec2 aP; uniform mat4 uVP; uniform vec4 uPl; uniform vec2 uHalf; out vec2 vL;
void main(){vL=aP*uHalf;float c=cos(uPl.z),s=sin(uPl.z);
 gl_Position=uVP*vec4(uPl.x+vL.x*c-vL.y*s,.003,uPl.y+vL.x*s+vL.y*c,1.);}"""
private const val FS_SH = """#version 300 es
precision highp float; uniform vec2 uSize; uniform vec2 uB; in vec2 vL; out vec4 o;
void main(){vec2 q=abs(vL)-uSize;float d=length(max(q,0.))+min(max(q.x,q.y),0.);
 o=vec4(0.,0.,0.,(1.-smoothstep(-uB.x*.3,uB.x,d))*uB.y);}"""

class DeskRenderer(private val act: Activity) : GLSurfaceView.Renderer {
    @Volatile var tiltX = 0f; @Volatile var tiltZ = 0f
    private var cx = 0f; private var cz = 0f
    private val pages = ArrayList<Page>()
    private var grab: Page? = null
    private var tx = 0f; private var tz = 0f; private var gox = 0f; private var goz = 0f
    private var downT = 0L; private var sx = 0f; private var sy = 0f; private var moved = false; private var lastT = 0L
    private var w = 1; private var h = 1; private var last = System.nanoTime()
    private val vp = FloatArray(16); private val proj = FloatArray(16); private val view = FloatArray(16)
    private var pDesk = 0; private var pPage = 0; private var pSh = 0
    private val LU = FloatArray(NV); private val LV = FloatArray(NV)
    private val P = FloatArray(NV * 3); private val N = FloatArray(NV * 3)
    private fun fb(n: Int) = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val posB = fb(NV * 3); private val nrmB = fb(NV * 3); private val uvB = fb(NV * 2)
    private val idxB = ByteBuffer.allocateDirect(NX * NY * 6 * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
    private val deskB = fb(12); private val quadB = fb(8)
    private val cal = Calendar.getInstance()
    private val sun = FloatArray(4); private val sunCol = FloatArray(3); private val amb = FloatArray(3)

    private fun sh(type: Int, src: String): Int { val s = GLES30.glCreateShader(type); GLES30.glShaderSource(s, src); GLES30.glCompileShader(s); return s }
    private fun prog(vs: String, fs: String): Int { val p = GLES30.glCreateProgram(); GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs)); GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs)); GLES30.glLinkProgram(p); return p }
    private fun u(p: Int, n: String) = GLES30.glGetUniformLocation(p, n)

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        pDesk = prog(VS_DESK, COMMON + FS_DESK); pPage = prog(VS_PAGE, COMMON + FS_PAGE); pSh = prog(VS_SH, FS_SH)
        for (iy in 0..NY) for (ix in 0..NX) { val i = iy * (NX + 1) + ix; LU[i] = ix / NX.toFloat() - .5f; LV[i] = iy / NY.toFloat() - .5f; uvB.put(ix / NX.toFloat()).put(iy / NY.toFloat()) }
        uvB.position(0)
        for (iy in 0 until NY) for (ix in 0 until NX) { val a = (iy * (NX + 1) + ix).toShort(); val b = (a + 1).toShort(); val d = (a + NX + 1).toShort(); val e = (d + 1).toShort(); idxB.put(a).put(d).put(b).put(b).put(d).put(e) }
        idxB.position(0)
        deskB.put(floatArrayOf(-3f, 0f, -5f, 3f, 0f, -5f, -3f, 0f, 4f, 3f, 0f, 4f)).position(0)
        quadB.put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)).position(0)
        GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        pages.clear(); loadApps()
    }

    private fun loadApps() {
        val pm = act.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != act.packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }.take(8)
        val rnd = java.util.Random(7)
        list.forEachIndexed { i, ri ->
            val bmp = pageBitmap(ri.loadLabel(pm).toString(), ri.loadIcon(pm), ri.activityInfo.packageName.hashCode())
            val t = IntArray(1); GLES30.glGenTextures(1, t, 0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0); GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR); bmp.recycle()
            val p = Page(ri.activityInfo.packageName, t[0]); p.x = ((i % 2) - .5f) * .75f + (rnd.nextFloat() - .5f) * .15f; p.z = -1.3f + (i / 2) * .62f
            p.rot = (rnd.nextFloat() - .5f) * .5f; pages.add(p)
        }
    }

    private fun pageBitmap(label: String, icon: Drawable?, seed: Int): Bitmap {
        val b = Bitmap.createBitmap(480, 640, Bitmap.Config.ARGB_8888); val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val shape = Path().apply { addRoundRect(RectF(6f, 6f, 474f, 634f), 10f, 10f, Path.Direction.CW) }
        c.save(); c.clipPath(shape)
        p.shader = LinearGradient(0f, 0f, 0f, 640f, 0xFFF2EAD6.toInt(), 0xFFE6DABF.toInt(), Shader.TileMode.CLAMP); c.drawPaint(p); p.shader = null
        p.color = Color.HSVToColor(floatArrayOf(((seed and 0x7fffffff) % 360).toFloat(), .5f, .72f)); c.drawRect(0f, 0f, 480f, 62f, p)
        p.color = 0x22603C20; for (i in 0..6) c.drawLine(50f, 455f + i * 24f, 430f, 455f + i * 24f, p)
        c.restore()
        icon?.setBounds(120, 130, 360, 370); icon?.draw(c)
        p.color = 0xFF3A2C1A.toInt(); p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); p.textSize = 34f; p.textAlign = Paint.Align.CENTER
        c.drawText(label.take(14), 240f, 420f, p); return b
    }

    override fun onSurfaceChanged(g: GL10?, W: Int, H: Int) { w = W; h = H; GLES30.glViewport(0, 0, W, H); Matrix.perspectiveM(proj, 0, 55f, W.toFloat() / H, .1f, 30f) }

    private fun unproject(px: Float, py: Float): FloatArray {
        val inv = FloatArray(16); Matrix.invertM(inv, 0, vp, 0)
        val a = FloatArray(4); val b = FloatArray(4); val nx = 2 * px / w - 1; val ny = 1 - 2 * py / h
        Matrix.multiplyMV(a, 0, inv, 0, floatArrayOf(nx, ny, -1f, 1f), 0); Matrix.multiplyMV(b, 0, inv, 0, floatArrayOf(nx, ny, 1f, 1f), 0)
        for (i in 0..3) { if (i < 3) { a[i] /= a[3]; b[i] /= b[3] } }
        val t = -a[1] / (b[1] - a[1]); return floatArrayOf(a[0] + (b[0] - a[0]) * t, a[2] + (b[2] - a[2]) * t)
    }

    fun touch(a: Int, px: Float, py: Float, t: Long) {
        val q = unproject(px, py)
        when (a) {
            android.view.MotionEvent.ACTION_DOWN -> {
                for (i in pages.indices.reversed()) {
                    val p = pages[i]; val dx = q[0] - p.x; val dz = q[1] - p.z; val c = cos(-p.rot); val s = sin(-p.rot)
                    val lx = dx * c - dz * s; val lz = dx * s + dz * c
                    if (abs(lx) < PW / 2 && abs(lz) < PH / 2) {
                        pages.removeAt(i); pages.add(p); grab = p; p.gu = lx / PW; p.gv = lz / PH
                        gox = p.x - q[0]; goz = p.z - q[1]; tx = p.x; tz = p.z; downT = t; sx = px; sy = py; moved = false; break
                    }
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> grab?.let { tx = q[0] + gox; tz = q[1] + goz; if (hypot(px - sx, py - sy) > 24f) moved = true }
            else -> grab?.let { p ->
                if (a == android.view.MotionEvent.ACTION_UP && !moved && t - downT < 300) {
                    act.packageManager.getLaunchIntentForPackage(p.pkg)?.let { i -> act.runOnUiThread { act.startActivity(i) } }
                }
                grab = null
            }
        }
    }

    private fun env() {
        cal.timeInMillis = System.currentTimeMillis(); val hr = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f
        fun ss(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }
        val day = ss(5.5f, 8.5f, hr) * (1 - ss(17.5f, 20.5f, hr)); val e = (1 - abs(hr - 13f) / 7f).coerceIn(0f, 1f)
        sun[0] = -1f + 2f * ((hr - 6f) / 14f).coerceIn(0f, 1f); sun[1] = -1.2f + abs(hr - 13f) * .08f; sun[2] = day
        sunCol[0] = 1.3f; sunCol[1] = .6f + .75f * e; sunCol[2] = .3f + .85f * e
        amb[0] = .05f + day * (.45f - .03f * e); amb[1] = .06f + day * (.33f + .12f * e); amb[2] = .1f + day * (.25f + .25f * e)
    }

    private fun mesh(p: Page, dt: Float) {
        val c = cos(p.rot); val s = sin(p.rot); val sp = hypot(p.vx, p.vz)
        for (i in 0 until NV) {
            val w2 = (LU[i] - p.gu).let { it * it } + (LV[i] - p.gv).let { it * it }
            val t0 = (-p.ax * w2 * 8e-4f).coerceIn(-.15f, .15f); val t2 = (-p.az * w2 * 8e-4f).coerceIn(-.15f, .15f)
            val t1 = p.lift * (.035f + .1f * w2) + min(sp, 3f) * w2 * .02f
            for (k in 0..2) { val t = when (k) { 0 -> t0; 1 -> t1; else -> t2 }; val j = i * 3 + k
                p.vel[j] += ((t - p.off[j]) * 180f - p.vel[j] * 14f) * dt; p.off[j] += p.vel[j] * dt }
            val lx = LU[i] * PW; val lz = LV[i] * PH
            P[i * 3] = p.x + lx * c - lz * s + p.off[i * 3]; P[i * 3 + 1] = .004f + p.off[i * 3 + 1]; P[i * 3 + 2] = p.z + lx * s + lz * c + p.off[i * 3 + 2]
        }
        for (iy in 0..NY) for (ix in 0..NX) {
            val l = (iy * (NX + 1) + max(ix - 1, 0)) * 3; val r = (iy * (NX + 1) + min(ix + 1, NX)) * 3
            val up = (max(iy - 1, 0) * (NX + 1) + ix) * 3; val dn = (min(iy + 1, NY) * (NX + 1) + ix) * 3
            val tx0 = P[r] - P[l]; val ty = P[r + 1] - P[l + 1]; val tz0 = P[r + 2] - P[l + 2]
            val bx = P[dn] - P[up]; val by = P[dn + 1] - P[up + 1]; val bz = P[dn + 2] - P[up + 2]
            var nx = by * tz0 - bz * ty; var ny = bz * tx0 - bx * tz0; var nz = bx * ty - by * tx0
            val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-6f) * (if (ny < 0) -1f else 1f)
            val o = (iy * (NX + 1) + ix) * 3; N[o] = nx / len; N[o + 1] = ny / len; N[o + 2] = nz / len
        }
        posB.put(P).position(0); nrmB.put(N).position(0)
    }

    override fun onDrawFrame(g: GL10?) {
        val now = System.nanoTime(); val dt = min(.033f, (now - last) / 1e9f).coerceAtLeast(.001f); last = now
        val bx = 2.15f * w / h - .3f; env()
        cx += (tiltX - cx) * .1f; cz += (tiltZ - cz) * .1f
        val ex = cx; val ez = 2f + cz
        Matrix.setLookAtM(view, 0, ex, 4f, ez, 0f, 0f, -.2f, 0f, 1f, 0f); Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        for (p in pages) {
            if (p === grab) {
                val k = min(1f, 28f * dt); val nx = p.x + (tx - p.x) * k; val nz = p.z + (tz - p.z) * k
                p.vx += ((nx - p.x) / dt - p.vx) * .5f; p.vz += ((nz - p.z) / dt - p.vz) * .5f; p.x = nx; p.z = nz
            } else { p.x += p.vx * dt; p.z += p.vz * dt; val f = exp(-3.5f * dt); p.vx *= f; p.vz *= f }
            if (p.x < -bx) { p.x = -bx; p.vx = abs(p.vx) * .4f }; if (p.x > bx) { p.x = bx; p.vx = -abs(p.vx) * .4f }
            if (p.z < -2f) { p.z = -2f; p.vz = abs(p.vz) * .4f }; if (p.z > 1.5f) { p.z = 1.5f; p.vz = -abs(p.vz) * .4f }
            p.ax += ((p.vx - p.pvx) / dt - p.ax) * min(1f, 12f * dt); p.az += ((p.vz - p.pvz) / dt - p.az) * min(1f, 12f * dt); p.pvx = p.vx; p.pvz = p.vz
            p.lift += ((if (p === grab) 1f else 0f) - p.lift) * min(1f, 10f * dt)
        }
        GLES30.glClearColor(.02f, .01f, .01f, 1f); GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        fun envU(p: Int) { GLES30.glUniform4fv(u(p, "uSun"), 1, sun, 0); GLES30.glUniform3fv(u(p, "uSunCol"), 1, sunCol, 0); GLES30.glUniform3fv(u(p, "uAmb"), 1, amb, 0)
            GLES30.glUniform3f(u(p, "uEye"), ex, 4f, ez); GLES30.glUniform2f(u(p, "uRes"), w.toFloat(), h.toFloat()); GLES30.glUniformMatrix4fv(u(p, "uVP"), 1, false, vp, 0) }
        GLES30.glUseProgram(pDesk); envU(pDesk); GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 0, deskB)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        for (p in pages) {
            GLES30.glUseProgram(pSh); GLES30.glUniformMatrix4fv(u(pSh, "uVP"), 1, false, vp, 0)
            GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quadB)
            val lf = p.lift
            for (pass in 0..1) {
                val blur = if (pass == 0) .015f else .05f + lf * .12f; val op = if (pass == 0) .5f else .3f; val oz = if (pass == 0) .008f else .03f + lf * .18f
                GLES30.glUniform4f(u(pSh, "uPl"), p.x, p.z + oz, p.rot, 0f); GLES30.glUniform2f(u(pSh, "uHalf"), PW / 2 + blur * 1.5f, PH / 2 + blur * 1.5f)
                GLES30.glUniform2f(u(pSh, "uSize"), PW / 2, PH / 2); GLES30.glUniform2f(u(pSh, "uB"), blur, op); GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
            }
            mesh(p, dt)
            GLES30.glUseProgram(pPage); envU(pPage); GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex)
            GLES30.glEnableVertexAttribArray(1); GLES30.glEnableVertexAttribArray(2)
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 0, posB); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 0, uvB); GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, 0, nrmB)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, NX * NY * 6, GLES30.GL_UNSIGNED_SHORT, idxB)
            GLES30.glDisableVertexAttribArray(1); GLES30.glDisableVertexAttribArray(2)
        }
    }
}
