package com.desk.launcher
import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.*
import java.util.Calendar
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

const val NX = 10; const val NY = 14; const val NV = (NX + 1) * (NY + 1)
const val BX = -.5f; const val BZ = 1.15f; const val FX = .5f; const val FZ = 1.15f
const val PW = 0.56f; const val PH = 0.75f
class Page(val pkg: String, val tex: Int) {
    var x = 0f; var z = 0f; var rot = 0f; var vx = 0f; var vz = 0f; var pvx = 0f; var pvz = 0f
    var ax = 0f; var az = 0f; var lift = 0f; var gu = 0f; var gv = 0f; var label = ""; var wet = 0f; var hang = 0f; var hx = 0f; var burn = 0f; var hung = false
    val off = FloatArray(NV * 3); val vel = FloatArray(NV * 3)
}

private const val COMMON = """#version 300 es
precision highp float;
uniform vec4 uSun; uniform vec3 uSunCol; uniform vec3 uAmb; uniform vec3 uEye; uniform vec2 uRes;
float h21(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float sunMask(vec2 p){vec2 q=p-uSun.xy;q.x+=q.y*.35;vec2 d=abs(q)-vec2(.8,.95);
 float e=1.-smoothstep(-.02,.07,max(d.x,d.y));
 float b=smoothstep(.012,.03,abs(q.x))*smoothstep(.012,.03,abs(q.y-.08));return e*b*uSun.z;}
vec3 lampPool(vec2 p){vec2 d=p-vec2(1.,-1.6);return vec3(1.,.6,.3)*exp(-dot(d,d)*.55)*(.35+1.3*(1.-uSun.z));}
"""
private const val VS_DESK = """#version 300 es
layout(location=0) in vec3 aP; uniform mat4 uVP; out vec3 vW;
void main(){vW=aP;gl_Position=uVP*vec4(aP,1.);}"""
private const val FS_DESK = """
in vec3 vW; out vec4 o;
float grain(vec2 p){float pl=floor(p.y/.55);vec2 q=vec2(p.x*.9+pl*7.3,p.y*14.);
 float n=vn(q)*.6+vn(q*vec2(2.3,2.)+3.)*.3+vn(q*vec2(6.,5.))*.1;
 return mix(n,.5+.5*sin(p.y*22.+n*9.+pl*3.),.55);}
void main(){vec2 p=vW.xz;float g=grain(p);float pl=floor(p.y/.55);float f=fract(p.y/.55);
 vec3 al=mix(vec3(.15,.085,.05),vec3(.38,.21,.11),g)*(.8+.35*h21(vec2(pl,3.)));
 al*=mix(.4,1.,smoothstep(0.,.014,f)*smoothstep(0.,.014,1.-f));
 float r=length(p-vec2(-.85,1.1));al*=1.-.4*smoothstep(.2,.206,r)*(1.-smoothstep(.206,.23,r))*(.6+.4*vn(p*30.));
 vec3 n=normalize(vec3(-(grain(p+vec2(.004,0.))-g)*2.5,1.,-(grain(p+vec2(0.,.004))-g)*2.5));
 vec3 L=normalize(vec3(uSun.x*.2,.8,-.55));vec3 V=normalize(uEye-vW);float m=sunMask(p);
 vec3 c=al*(uAmb+uSunCol*m*max(dot(n,L),0.)+lampPool(p));
 c+=uSunCol*m*pow(max(dot(n,normalize(L+V)),0.),40.)*.35*(.4+g);
 vec2 sc=gl_FragCoord.xy/uRes-.5;c*=1.-dot(sc,sc)*.7;
 o=vec4(1.-exp(-c*2.2),1.);}"""
private const val VS_PAGE = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec2 aUV; layout(location=2) in vec3 aN;
uniform mat4 uVP; out vec3 vW; out vec2 vUV; out vec3 vN;
void main(){vW=aP;vUV=aUV;vN=aN;gl_Position=uVP*vec4(aP,1.);}"""
private const val FS_PAGE = """
uniform sampler2D uTex; uniform float uWet,uHang,uBurn; in vec3 vW; in vec2 vUV; in vec3 vN; out vec4 o;
void main(){vec4 t=texture(uTex,vUV);vec3 n=normalize(vN);vec3 L=normalize(vec3(uSun.x*.2,.8,-.55));
 float m=sunMask(vW.xz);float nl=dot(n,L);
 float fib=.96+.08*vn(vW.xz*260.)*vn(vW.xz*90.+7.);
 vec3 li=uAmb*(.65+.35*n.y)+uSunCol*m*(max(nl,0.)+max(-nl,0.)*.35)+lampPool(vW.xz);
 float bn=vn(vUV*14.)-uBurn*1.2;if(bn<0.)discard;
 vec3 tc=mix(t.rgb,t.rgb*vec3(.62,.72,.88),uWet);li=mix(li,li*.8,uWet)+uSunCol*uSun.z*uHang*.6;
 vec3 c=tc*li*fib;c+=uSunCol*uWet*pow(max(dot(n,normalize(L+normalize(uEye-vW))),0.),50.)*m*.5;
 float bu=step(.001,uBurn);c=mix(c,vec3(.04,.025,.015),smoothstep(.25,0.,bn)*bu);c=1.-exp(-c*2.2);c+=vec3(1.,.4,.05)*smoothstep(.07,0.,bn)*bu*1.5;
 o=vec4(c,t.a);}"""
private const val VS_SO = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; uniform mat4 uVP; uniform mat4 uM; out vec3 vW; out vec3 vN;
void main(){vec4 w=uM*vec4(aP,1.);vW=w.xyz;vN=mat3(uM)*aN;gl_Position=uVP*w;}"""
private const val FS_SO = """
uniform vec4 uCol; uniform vec4 uMat; uniform vec3 uSkyT; uniform vec3 uSkyB; uniform float uT;
in vec3 vW; in vec3 vN; out vec4 o;
void main(){
 if(uMat.z>.5){vec3 c=mix(uSkyB,uSkyT,smoothstep(.6,2.9,vW.y));c+=step(.996,h21(floor(vW.xy*70.)))*max(0.,1.-uSun.z*3.)*.9;o=vec4(c,1.);return;}
 vec3 n=normalize(vN);vec3 L=normalize(vec3(uSun.x*.2,.8,-.55));vec3 V=normalize(uEye-vW);
 if(uMat.w>.5){vec2 q=vW.xz-vec2(-.5,1.15);float r=length(q);float rp=sin(r*38.-uT*2.)*exp(-r*3.5)*.5;vec2 dq=q/max(r,.001);
  n=normalize(vec3(dq.x*rp*.15,1.,dq.y*rp*.15));float f=pow(1.-max(dot(n,V),0.),3.);
  vec3 c=mix(vec3(.08,.2,.26),mix(uSkyB,uSkyT,.5),f*.8+.2)+pow(max(dot(n,normalize(L+V)),0.),90.)*uSun.z*2.;
  o=vec4(1.-exp(-c*1.8),.92);return;}
 float d=max(dot(n,L),0.);vec3 li=uAmb*(.6+.4*n.y)+uSunCol*uSun.z*d*.5+lampPool(vW.xz);
 vec3 c=uCol.rgb*li+uCol.rgb*uMat.y*(.8+.4*sin(uT*30.+vW.x*40.));
 c+=pow(max(dot(n,normalize(L+V)),0.),30.)*uMat.x*(uSun.z+.15)*.6;
 o=vec4(1.-exp(-c*2.2),1.);}"""
private const val VS_SH = """#version 300 es
layout(location=0) in vec2 aP; uniform mat4 uVP; uniform vec4 uPl; uniform vec2 uHalf; out vec2 vL;
void main(){vL=aP*uHalf;float c=cos(uPl.z),s=sin(uPl.z);
 gl_Position=uVP*vec4(uPl.x+vL.x*c-vL.y*s,.003,uPl.y+vL.x*s+vL.y*c,1.);}"""
private const val FS_SH = """#version 300 es
precision highp float; uniform vec2 uSize; uniform vec2 uB; in vec2 vL; out vec4 o;
void main(){vec2 q=abs(vL)-uSize;float d=length(max(q,0.))+min(max(q.x,q.y),0.);
 o=vec4(0.,0.,0.,(1.-smoothstep(-uB.x*.3,uB.x,d))*uB.y);}"""

class DeskRenderer(private val act: Activity) : GLSurfaceView.Renderer {
    @Volatile var tiltX = 0f; @Volatile var tiltZ = 0f
    private var cx = 0f; private var cz = 0f
    private val pages = ArrayList<Page>()
    private var grab: Page? = null
    private var tx = 0f; private var tz = 0f; private var gox = 0f; private var goz = 0f
    private var downT = 0L; private var sx = 0f; private var sy = 0f; private var moved = false; private var lastT = 0L
    private var w = 1; private var h = 1; private var last = System.nanoTime()
    private val vp = FloatArray(16); private val proj = FloatArray(16); private val view = FloatArray(16)
    private var pDesk = 0; private var pPage = 0; private var pSh = 0
    private val LU = FloatArray(NV); private val LV = FloatArray(NV)
    private val P = FloatArray(NV * 3); private val N = FloatArray(NV * 3)
    private fun fb(n: Int) = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val posB = fb(NV * 3); private val nrmB = fb(NV * 3); private val uvB = fb(NV * 2)
    private val idxB = ByteBuffer.allocateDirect(NX * NY * 6 * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
    private val deskB = fb(12); private val quadB = fb(8)
    private val cal = Calendar.getInstance()
    private lateinit var sfx: Sfx; private var tapObj = -1; private var ox0 = 0f; private var oy0 = 0f; private var fingX = 0f; private var fingZ = 0f; private var music = -1; private var lastRus = 0L; private var tm = 0f; private var eyeX = 0f; private var eyeY = 3.2f; private var eyeZ = 3.4f; private var pSo = 0; private val mm = FloatArray(16)
    private val skyT = FloatArray(3); private val skyB = FloatArray(3)
    private lateinit var boxP: FloatBuffer; private lateinit var boxN: FloatBuffer; private lateinit var cylP: FloatBuffer; private lateinit var cylN: FloatBuffer
    private val sun = FloatArray(4); private val sunCol = FloatArray(3); private val amb = FloatArray(3)

    private fun sh(type: Int, src: String): Int { val s = GLES30.glCreateShader(type); GLES30.glShaderSource(s, src); GLES30.glCompileShader(s); return s }
    private fun prog(vs: String, fs: String): Int { val p = GLES30.glCreateProgram(); GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs)); GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs)); GLES30.glLinkProgram(p); return p }
    private fun u(p: Int, n: String) = GLES30.glGetUniformLocation(p, n)

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        pDesk = prog(VS_DESK, COMMON + FS_DESK); pPage = prog(VS_PAGE, COMMON + FS_PAGE); pSh = prog(VS_SH, FS_SH); pSo = prog(VS_SO, COMMON + FS_SO); prims()
        for (iy in 0..NY) for (ix in 0..NX) { val i = iy * (NX + 1) + ix; LU[i] = ix / NX.toFloat() - .5f; LV[i] = iy / NY.toFloat() - .5f; uvB.put(ix / NX.toFloat()).put(iy / NY.toFloat()) }
        uvB.position(0)
        for (iy in 0 until NY) for (ix in 0 until NX) { val a = (iy * (NX + 1) + ix).toShort(); val b = (a + 1).toShort(); val d = (a + NX + 1).toShort(); val e = (d + 1).toShort(); idxB.put(a).put(d).put(b).put(b).put(d).put(e) }
        idxB.position(0)
        deskB.put(floatArrayOf(-3f, 0f, -3f, 3f, 0f, -3f, -3f, 0f, 4f, 3f, 0f, 4f)).position(0)
        quadB.put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)).position(0)
        GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        if (!::sfx.isInitialized) sfx = Sfx(); pages.clear(); loadApps()
    }

    private fun loadApps() {
        val pm = act.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != act.packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }.take(8)
        val rnd = java.util.Random(7)
        list.forEachIndexed { i, ri ->
            val bmp = pageBitmap(ri.loadLabel(pm).toString(), ri.loadIcon(pm), ri.activityInfo.packageName.hashCode())
            val t = IntArray(1); GLES30.glGenTextures(1, t, 0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0); GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR); bmp.recycle()
            val p = Page(ri.activityInfo.packageName, t[0]); p.label = ri.loadLabel(pm).toString(); p.x = ((i % 3) - 1f) * .6f + (rnd.nextFloat() - .5f) * .08f; p.z = -1.45f + (i / 3) * .8f
            p.rot = (rnd.nextFloat() - .5f) * .5f; pages.add(p)
        }
    }

    private fun pageBitmap(label: String, icon: Drawable?, seed: Int): Bitmap {
        val b = Bitmap.createBitmap(480, 640, Bitmap.Config.ARGB_8888); val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val shape = Path().apply { addRoundRect(RectF(6f, 6f, 474f, 634f), 10f, 10f, Path.Direction.CW) }
        c.save(); c.clipPath(shape)
        p.shader = LinearGradient(0f, 0f, 0f, 640f, 0xFFF2EAD6.toInt(), 0xFFE6DABF.toInt(), Shader.TileMode.CLAMP); c.drawPaint(p); p.shader = null
        p.color = Color.HSVToColor(floatArrayOf(((seed and 0x7fffffff) % 360).toFloat(), .5f, .72f)); c.drawRect(0f, 0f, 480f, 62f, p)
        p.color = 0x22603C20; for (i in 0..6) c.drawLine(50f, 455f + i * 24f, 430f, 455f + i * 24f, p)
        c.restore()
        icon?.setBounds(120, 130, 360, 370); icon?.draw(c)
        p.color = 0xFF3A2C1A.toInt(); p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); p.textSize = 34f; p.textAlign = Paint.Align.CENTER
        c.drawText(label.take(14), 240f, 420f, p); return b
    }

    override fun onSurfaceChanged(g: GL10?, W: Int, H: Int) { w = W; h = H; GLES30.glViewport(0, 0, W, H); Matrix.perspectiveM(proj, 0, 60f, W.toFloat() / H, .1f, 30f) }

    private fun unproject(px: Float, py: Float): FloatArray {
        val inv = FloatArray(16); Matrix.invertM(inv, 0, vp, 0)
        val a = FloatArray(4); val b = FloatArray(4); val nx = 2 * px / w - 1; val ny = 1 - 2 * py / h
        Matrix.multiplyMV(a, 0, inv, 0, floatArrayOf(nx, ny, -1f, 1f), 0); Matrix.multiplyMV(b, 0, inv, 0, floatArrayOf(nx, ny, 1f, 1f), 0)
        for (i in 0..3) { if (i < 3) { a[i] /= a[3]; b[i] /= b[3] } }
        val t = -a[1] / (b[1] - a[1]); return floatArrayOf(a[0] + (b[0] - a[0]) * t, a[2] + (b[2] - a[2]) * t)
    }

    private fun screenOf(x: Float, y: Float, z: Float): FloatArray { val o = FloatArray(4); Matrix.multiplyMV(o, 0, vp, 0, floatArrayOf(x, y, z, 1f), 0); return floatArrayOf((o[0] / o[3] * .5f + .5f) * w, (.5f - o[1] / o[3] * .5f) * h) }
    private fun hangIt(p: Page): Boolean { val used = pages.filter { it.hung }.map { it.hx }
        val sl = floatArrayOf(-.62f, 0f, .62f).firstOrNull { c -> used.none { abs(it - c) < .1f } } ?: return false
        p.hung = true; p.hx = sl; sfx.click(); return true }
    private fun drop(p: Page) {
        if (hypot(fingX - BX, fingZ - BZ) < .5f || hypot(p.x - BX, p.z - BZ) < .45f) { p.wet = 1f; sfx.splash() }
        else if (hypot(fingX - FX, fingZ - FZ) < .45f || hypot(p.x - FX, p.z - FZ) < .4f) { p.burn = .001f; sfx.burn() }
        else if ((fingZ < -1.2f || p.z < -1.35f) && p.wet > .05f) hangIt(p)
    }
    private fun rus(p: Page) { val sp = hypot(p.vx, p.vz); val n = System.nanoTime(); if (sp > 1f && n - lastRus > 110_000_000L) { lastRus = n; sfx.rustle(min(1f, sp * .15f)) } }
    private fun pageAt(x: Float, z: Float) = pages.any { !it.hung && run { val dx = x - it.x; val dz = z - it.z; val c = cos(-it.rot); val s = sin(-it.rot); abs(dx * c - dz * s) < PW / 2 && abs(dx * s + dz * c) < PH / 2 } }
    private val OB = arrayOf(floatArrayOf(-.75f, -2.3f, .18f, .25f), floatArrayOf(-.18f, -2.5f, .3f, .25f), floatArrayOf(.6f, -2.45f, .36f, .22f))
    private fun hitObj(x: Float, z: Float): Int { for (i in OB.indices) { val o = OB[i]; if (abs(x - o[0]) < o[2] && z > o[1] - o[3] - .5f && z < o[1] + o[3]) return i }; return -1 }
    private fun toggleMusic(i: Int) { music = if (music == i) -1 else i; sfx.setMusic(music) }
    private fun objAct(i: Int) { sfx.click(); when (i) { 0 -> toggleMusic(0); 1 -> act.runOnUiThread { (act as MainActivity).openTerm() }; else -> toggleMusic(1) } }
    fun pauseSfx() { if (::sfx.isInitialized) sfx.pause() }
    fun resumeSfx() { if (::sfx.isInitialized) sfx.resume() }
    fun cmd(line: String, cb: (String) -> Unit) {
        val a = line.split(" ", limit = 2); val c = a[0].lowercase(); val arg = a.getOrNull(1)?.trim()?.lowercase() ?: ""
        val p = if (arg.isEmpty()) null else pages.firstOrNull { it.label.lowercase().startsWith(arg) }
        when (c) {
            "help" -> cb("ls, open X, soak X, dry X, hang X, burn X, play, radio, ram, clear, exit")
            "ls" -> cb(pages.joinToString("\n") { (if (it.hung) "^ " else if (it.wet > .1f) "~ " else "* ") + it.label } + "\n(* live  ~ wet  ^ hung)")
            "ram" -> { val rt = Runtime.getRuntime(); cb("heap " + (rt.totalMemory() - rt.freeMemory()) / 1048576 + " MB, " + pages.count { it.wet < .1f } + " live pages") }
            "play" -> { toggleMusic(0); cb(if (music == 0) "ipod playing" else "stopped") }
            "radio" -> { toggleMusic(1); cb(if (music == 1) "radio on" else "radio off") }
            "open", "soak", "dry", "burn", "hang" -> if (p == null) cb("no such page") else when (c) {
                "open" -> { act.packageManager.getLaunchIntentForPackage(p.pkg)?.let { i -> act.runOnUiThread { act.startActivity(i) } }; cb("launching " + p.label) }
                "soak" -> { p.wet = 1f; sfx.splash(); cb("soaked") }
                "dry" -> { p.wet = 0f; cb("dry") }
                "burn" -> { p.burn = .001f; sfx.burn(); cb("burning") }
                else -> cb(if (p.wet < .05f) "page is dry, soak it first" else if (hangIt(p)) "hung" else "line is full") }
            else -> cb("unknown: " + c)
        }
    }
    fun touch(a: Int, px: Float, py: Float, t: Long) {
        val q = unproject(px, py); fingX = q[0]; fingZ = q[1]
        if (a == android.view.MotionEvent.ACTION_DOWN) { ox0 = px; oy0 = py; tapObj = if (pageAt(q[0], q[1])) -1 else hitObj(q[0], q[1]) }
        if (a == android.view.MotionEvent.ACTION_UP && tapObj >= 0 && grab == null && hypot(px - ox0, py - oy0) < 40f) { objAct(tapObj); tapObj = -1 }
        when (a) {
            android.view.MotionEvent.ACTION_DOWN -> {
                for (p in pages) if (p.hung) { val sc = screenOf(p.hx, 1.5f, -2.8f)
                    if (hypot(px - sc[0], py - sc[1]) < .16f * h) { p.hung = false; p.x = p.hx; p.z = -1.9f; pages.remove(p); pages.add(p); grab = p; p.gu = 0f; p.gv = -.4f; tx = p.x; tz = p.z; gox = 0f; goz = 0f; downT = t; sx = px; sy = py; moved = true; return } }
                for (i in pages.indices.reversed()) {
                    val p = pages[i]; val dx = q[0] - p.x; val dz = q[1] - p.z; val c = cos(-p.rot); val s = sin(-p.rot)
                    val lx = dx * c - dz * s; val lz = dx * s + dz * c
                    if (!p.hung && abs(lx) < PW / 2 && abs(lz) < PH / 2) {
                        pages.removeAt(i); pages.add(p); grab = p; sfx.rustle(.6f); p.gu = lx / PW; p.gv = lz / PH
                        gox = p.x - q[0]; goz = p.z - q[1]; tx = p.x; tz = p.z; downT = t; sx = px; sy = py; moved = false; break
                    }
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> grab?.let { tx = q[0] + gox; tz = q[1] + goz; if (hypot(px - sx, py - sy) > 24f) moved = true }
            else -> grab?.let { p ->
                if (a == android.view.MotionEvent.ACTION_UP && !moved && t - downT < 300) {
                    if (p.wet < .15f) act.packageManager.getLaunchIntentForPackage(p.pkg)?.let { i -> act.runOnUiThread { act.startActivity(i) } } else p.vx = 1.5f
                }
                if (a == android.view.MotionEvent.ACTION_UP && moved) drop(p); grab = null
            }
        }
    }

    private fun env() {
        cal.timeInMillis = System.currentTimeMillis(); val hr = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f
        fun ss(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }
        val day = ss(5.5f, 8.5f, hr) * (1 - ss(17.5f, 20.5f, hr)); val e = (1 - abs(hr - 13f) / 7f).coerceIn(0f, 1f)
        sun[0] = -1f + 2f * ((hr - 6f) / 14f).coerceIn(0f, 1f); sun[1] = -1.6f + abs(hr - 13f) * .12f; sun[2] = day
        sunCol[0] = 1.3f; sunCol[1] = .6f + .75f * e; sunCol[2] = .3f + .85f * e
        amb[0] = .16f + day * (.45f - .03f * e); amb[1] = .18f + day * (.33f + .12f * e); amb[2] = .30f + day * (.25f + .25f * e)
        skyT[0] = .01f + day * .34f; skyT[1] = .02f + day * .58f; skyT[2] = .06f + day * .94f
        skyB[0] = .03f + day * (.8f + .2f * (1f - e)); skyB[1] = .04f + day * (.55f + .35f * e); skyB[2] = .1f + day * (.3f + .65f * e)
    }

    private fun mesh(p: Page, dt: Float) {
        val c = cos(p.rot); val s = sin(p.rot); val sp = hypot(p.vx, p.vz)
        for (i in 0 until NV) {
            val w2 = (LU[i] - p.gu).let { it * it } + (LV[i] - p.gv).let { it * it }
            val t0 = (-p.ax * w2 * 8e-4f).coerceIn(-.15f, .15f); val t2 = (-p.az * w2 * 8e-4f).coerceIn(-.15f, .15f)
            val wf = 1f - .7f * p.wet; val t1 = p.lift * (.035f + .1f * w2) + min(sp, 3f) * w2 * .02f
            for (k in 0..2) { val t = when (k) { 0 -> t0; 1 -> t1; else -> t2 }; val j = i * 3 + k
                p.vel[j] += ((t * wf - p.off[j]) * 180f - p.vel[j] * 14f) * dt; p.off[j] += p.vel[j] * dt }
            val lx = LU[i] * PW; val lz = LV[i] * PH
            val hxp = p.hx + lx; val hyp = 2f - (LV[i] + .5f) * PH; val hzp = -2.8f + sin(tm * 1.3f + LV[i] * 2f) * .015f * (LV[i] + .5f)
            val lxw = p.x + lx * c - lz * s; val lzw = p.z + lx * s + lz * c; val hg = p.hang
            P[i * 3] = lxw + (hxp - lxw) * hg + p.off[i * 3]; P[i * 3 + 1] = .004f + (hyp - .004f) * hg + p.off[i * 3 + 1]; P[i * 3 + 2] = lzw + (hzp - lzw) * hg + p.off[i * 3 + 2]
        }
        for (iy in 0..NY) for (ix in 0..NX) {
            val l = (iy * (NX + 1) + max(ix - 1, 0)) * 3; val r = (iy * (NX + 1) + min(ix + 1, NX)) * 3
            val up = (max(iy - 1, 0) * (NX + 1) + ix) * 3; val dn = (min(iy + 1, NY) * (NX + 1) + ix) * 3
            val tx0 = P[r] - P[l]; val ty = P[r + 1] - P[l + 1]; val tz0 = P[r + 2] - P[l + 2]
            val bx = P[dn] - P[up]; val by = P[dn + 1] - P[up + 1]; val bz = P[dn + 2] - P[up + 2]
            var nx = by * tz0 - bz * ty; var ny = bz * tx0 - bx * tz0; var nz = bx * ty - by * tx0
            val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-6f) * (if (nx * (eyeX - P[(iy * (NX + 1) + ix) * 3]) + ny * (eyeY - P[(iy * (NX + 1) + ix) * 3 + 1]) + nz * (eyeZ - P[(iy * (NX + 1) + ix) * 3 + 2]) < 0f) -1f else 1f)
            val o = (iy * (NX + 1) + ix) * 3; N[o] = nx / len; N[o + 1] = ny / len; N[o + 2] = nz / len
        }
        posB.put(P).position(0); nrmB.put(N).position(0)
    }

    override fun onDrawFrame(g: GL10?) {
        val now = System.nanoTime(); val dt = min(.033f, (now - last) / 1e9f).coerceAtLeast(.001f); last = now
        val bx = 1.96f * w / h - .28f; env()
        cx += (tiltX - cx) * .1f; cz += (tiltZ - cz) * .1f
        val ex = cx; val ez = 3.4f + cz; eyeX = ex; eyeY = 3.2f; eyeZ = ez; tm += dt
        Matrix.setLookAtM(view, 0, ex, 3.2f, ez, 0f, .4f, -1.2f, 0f, 1f, 0f); Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        for (p in pages) {
            if (p === grab) {
                val k = min(1f, 28f * dt); val nx = p.x + (tx - p.x) * k; val nz = p.z + (tz - p.z) * k
                p.vx += ((nx - p.x) / dt - p.vx) * .5f; p.vz += ((nz - p.z) / dt - p.vz) * .5f; p.x = nx; p.z = nz; rus(p)
            } else { p.x += p.vx * dt; p.z += p.vz * dt; val f = exp(-3.5f * dt); p.vx *= f; p.vz *= f }
            if (p.x < -bx) { p.x = -bx; p.vx = abs(p.vx) * .4f }; if (p.x > bx) { p.x = bx; p.vx = -abs(p.vx) * .4f }
            if (p.z < -1.9f) { p.z = -1.9f; p.vz = abs(p.vz) * .4f }; if (p.z > 1.3f) { p.z = 1.3f; p.vz = -abs(p.vz) * .4f }
            p.ax += ((p.vx - p.pvx) / dt - p.ax) * min(1f, 12f * dt); p.az += ((p.vz - p.pvz) / dt - p.az) * min(1f, 12f * dt); p.pvx = p.vx; p.pvz = p.vz
            p.lift += ((if (p === grab) 1f else 0f) - p.lift) * min(1f, 10f * dt)
            p.hang += ((if (p.hung) 1f else 0f) - p.hang) * min(1f, 4f * dt)
            if (p.hung) { p.x += (p.hx - p.x) * .15f; p.z += (-2f - p.z) * .15f; p.vx = 0f; p.vz = 0f }
            val dry = if (p.hung) .02f + .1f * sun[2] else if (p.z < -1.2f) .01f + .04f * sun[2] else .004f
            if (p !== grab && p.burn == 0f && hypot(p.x - BX, p.z - BZ) < .4f) p.wet = 1f else p.wet = max(0f, p.wet - dry * dt)
            if (p.burn > 0f) { p.burn += dt * .5f; if (p.burn > 1.25f) { p.burn = 0f; p.wet = 0f; p.x = 0f; p.z = -.2f; p.vx = 0f; p.vz = 0f } }
        }
        GLES30.glClearColor(.02f, .01f, .01f, 1f); GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        fun envU(p: Int) { GLES30.glUniform4fv(u(p, "uSun"), 1, sun, 0); GLES30.glUniform3fv(u(p, "uSunCol"), 1, sunCol, 0); GLES30.glUniform3fv(u(p, "uAmb"), 1, amb, 0)
            GLES30.glUniform3f(u(p, "uEye"), ex, 3.2f, ez); GLES30.glUniform2f(u(p, "uRes"), w.toFloat(), h.toFloat()); GLES30.glUniformMatrix4fv(u(p, "uVP"), 1, false, vp, 0) }
        GLES30.glUseProgram(pDesk); envU(pDesk); GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 0, deskB)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glUseProgram(pSo); envU(pSo); room()
        for (p in pages) {
            GLES30.glUseProgram(pSh); GLES30.glUniformMatrix4fv(u(pSh, "uVP"), 1, false, vp, 0)
            GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quadB)
            val lf = p.lift
            for (pass in 0..(if (p.hang > .5f) -1 else 1)) {
                val blur = if (pass == 0) .015f else .05f + lf * .12f; val op = if (pass == 0) .5f else .3f; val oz = if (pass == 0) .008f else .03f + lf * .18f
                GLES30.glUniform4f(u(pSh, "uPl"), p.x, p.z + oz, p.rot, 0f); GLES30.glUniform2f(u(pSh, "uHalf"), PW / 2 + blur * 1.5f, PH / 2 + blur * 1.5f)
                GLES30.glUniform2f(u(pSh, "uSize"), PW / 2, PH / 2); GLES30.glUniform2f(u(pSh, "uB"), blur, op); GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
            }
            mesh(p, dt)
            GLES30.glUseProgram(pPage); envU(pPage); GLES30.glUniform1f(u(pPage, "uWet"), p.wet); GLES30.glUniform1f(u(pPage, "uHang"), p.hang); GLES30.glUniform1f(u(pPage, "uBurn"), p.burn); GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex)
            GLES30.glEnableVertexAttribArray(1); GLES30.glEnableVertexAttribArray(2)
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 0, posB); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 0, uvB); GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, 0, nrmB)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, NX * NY * 6, GLES30.GL_UNSIGNED_SHORT, idxB)
            GLES30.glDisableVertexAttribArray(1); GLES30.glDisableVertexAttribArray(2)
        }
    }

    private fun prims() {
        val bp = ArrayList<Float>(); val bn = ArrayList<Float>()
        val ns = arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f))
        for (n in ns) {
            val u = if (abs(n[1]) > .5f) floatArrayOf(1f, 0f, 0f) else floatArrayOf(0f, 1f, 0f)
            val v = floatArrayOf(n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
            for (q in intArrayOf(0, 1, 2, 0, 2, 3)) { val su = if (q == 1 || q == 2) .5f else -.5f; val sv = if (q >= 2) .5f else -.5f
                for (k in 0..2) { bp.add(n[k] * .5f + u[k] * su + v[k] * sv); bn.add(n[k]) } }
        }
        val cp = ArrayList<Float>(); val cn = ArrayList<Float>()
        fun vtx(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) { cp.add(x); cp.add(y); cp.add(z); cn.add(nx); cn.add(ny); cn.add(nz) }
        for (i in 0 until 20) { val a0 = i * 6.2832f / 20; val a1 = (i + 1) * 6.2832f / 20
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            vtx(c0, 0f, s0, c0, 0f, s0); vtx(c1, 0f, s1, c1, 0f, s1); vtx(c1, 1f, s1, c1, 0f, s1)
            vtx(c0, 0f, s0, c0, 0f, s0); vtx(c1, 1f, s1, c1, 0f, s1); vtx(c0, 1f, s0, c0, 0f, s0)
            vtx(0f, 1f, 0f, 0f, 1f, 0f); vtx(c0, 1f, s0, 0f, 1f, 0f); vtx(c1, 1f, s1, 0f, 1f, 0f) }
        fun mk(l: ArrayList<Float>) = fb(l.size).also { it.put(l.toFloatArray()).position(0) }
        boxP = mk(bp); boxN = mk(bn); cylP = mk(cp); cylN = mk(cn)
    }

    private fun room() {
        val uM = u(pSo, "uM"); val uC = u(pSo, "uCol"); val uMt = u(pSo, "uMat")
        GLES30.glUniform3fv(u(pSo, "uSkyT"), 1, skyT, 0); GLES30.glUniform3fv(u(pSo, "uSkyB"), 1, skyB, 0); GLES30.glUniform1f(u(pSo, "uT"), tm); GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnableVertexAttribArray(0); GLES30.glEnableVertexAttribArray(1)
        fun s(cyl: Boolean, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, r: Float, g: Float, b: Float, gl: Float = 0f, em: Float = 0f, k: Int = 0, rx: Float = 0f) {
            Matrix.setIdentityM(mm, 0); Matrix.translateM(mm, 0, x, y, z); if (rx != 0f) Matrix.rotateM(mm, 0, rx, 1f, 0f, 0f); Matrix.scaleM(mm, 0, sx, sy, sz)
            GLES30.glUniformMatrix4fv(uM, 1, false, mm, 0); GLES30.glUniform4f(uC, r, g, b, 1f); GLES30.glUniform4f(uMt, gl, em, if (k == 1) 1f else 0f, if (k == 2) 1f else 0f)
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 0, if (cyl) cylP else boxP); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 0, if (cyl) cylN else boxN)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, if (cyl) 180 else 36)
        }
        s(false, 0f, 1.7f, -3.5f, 8f, 3.6f, .05f, 0f, 0f, 0f, 0f, 0f, 1)
        s(false, -2f, 1.6f, -3f, 2f, 3.4f, .2f, .72f, .67f, .58f); s(false, 2f, 1.6f, -3f, 2f, 3.4f, .2f, .72f, .67f, .58f)
        s(false, 0f, .4f, -3f, 2f, 1f, .2f, .72f, .67f, .58f); s(false, 0f, 2.9f, -3f, 2f, .8f, .2f, .72f, .67f, .58f)
        s(false, 0f, .92f, -2.88f, 2.3f, .06f, .3f, .9f, .88f, .82f, .3f); s(false, 0f, 2.52f, -2.95f, 2.2f, .06f, .15f, .9f, .88f, .82f)
        s(false, -1.02f, 1.7f, -2.95f, .06f, 1.6f, .15f, .9f, .88f, .82f); s(false, 1.02f, 1.7f, -2.95f, .06f, 1.6f, .15f, .9f, .88f, .82f)
        s(false, 0f, 1.7f, -2.97f, .04f, 1.6f, .04f, .9f, .88f, .82f); s(false, 0f, 1.7f, -2.97f, 2f, .04f, .04f, .9f, .88f, .82f)
        for (k in 0 until 64) { val t = (k + .5f) / 64f; s(false, -.95f + 1.9f * t, 2f - .07f * (1f - (2f * t - 1f) * (2f * t - 1f)), -2.85f, .03f, .012f, .012f, .6f, .5f, .35f) }
        for (p in pages) if (p.hang > .5f) { s(false, p.hx - .22f, 2f, -2.82f, .04f, .09f, .03f, .5f, .35f, .2f); s(false, p.hx + .22f, 2f, -2.82f, .04f, .09f, .03f, .5f, .35f, .2f) }
        s(true, BX, 0f, BZ, .34f, .1f, .34f, .9f, .92f, .95f, .8f); s(true, BX, .101f, BZ, .28f, .002f, .28f, 0f, 0f, 0f, 0f, 0f, 2)
        s(true, FX, 0f, FZ, .24f, .07f, .24f, .12f, .12f, .13f, .5f); s(true, FX, .071f, FZ, .15f, .005f, .15f, .05f, .05f, .05f)
        for (i in 0 until 10) { val a = i * .6283f; val fh = .05f + .035f * sin(tm * 17f + i * 2.1f)
            s(false, FX + cos(a) * .11f, .075f + fh / 2, FZ + sin(a) * .11f, .025f, fh, .025f, .25f, .55f, 1f, 0f, 2f) }
        val pl = music >= 0; val bt = if (pl) abs(sin(tm * 6f)) else 0f
        s(false, -.75f, .02f, -2.3f, .26f, .04f, .42f, .92f, .93f, .95f, .8f)
        s(false, -.75f, .042f, -2.42f, .2f, .004f, .14f, if (music == 0) .5f else .08f, if (music == 0) .8f else .15f, if (music == 0) .9f else .2f, 0f, if (music == 0) 1f else .3f)
        for (k in 0..3) { val hh = if (music == 0) .008f + .035f * abs(sin(tm * 6f + k * 1.7f)) else .006f; s(false, -.81f + k * .04f, .044f + hh / 2, -2.42f, .025f, hh, .025f, .4f, .9f, 1f, 0f, 2f) }
        s(true, -.75f, .04f, -2.2f, .085f, .004f, .085f, .78f, .78f, .8f, .5f); s(true, -.75f, .044f, -2.2f, .035f, .002f, .035f, .95f, .95f, .95f, .6f)
        s(false, -.18f, .02f, -2.5f, .3f, .04f, .3f, .22f, .2f, .18f); s(false, -.18f, .24f, -2.5f, .5f, .4f, .42f, .74f, .7f, .6f, .2f)
        s(false, -.18f, .25f, -2.285f, .36f, .28f, .02f, .06f, .55f, .2f, 0f, .6f + .15f * sin(tm * 25f))
        for (k in 0..2) s(false, -.22f, .31f - k * .05f, -2.272f, .16f - k * .03f, .012f, .004f, .5f, 1f, .6f, 0f, 1.5f)
        s(false, .6f, .17f, -2.45f, .68f, .34f, .26f, .13f, .13f, .14f, .6f); s(false, .6f, .37f, -2.45f, .5f, .03f, .03f, .6f, .6f, .62f, .8f)
        for (sx in intArrayOf(-1, 1)) { val pu = 1f + (if (pl) .12f * bt else 0f)
            s(true, .6f + sx * .2f, .16f, -2.318f, .11f, .015f, .11f, .06f, .06f, .07f, .3f, 0f, 0, 90f); s(true, .6f + sx * .2f, .16f, -2.3f, .04f * pu, .012f, .04f * pu, .3f, .3f, .32f, .5f, 0f, 0, 90f) }
        s(false, .6f, .27f, -2.318f, .22f, .07f, .01f, .85f, .8f, .6f, 0f, if (pl) .7f else .15f); s(false, .6f + sin(tm * .4f) * .08f, .27f, -2.31f, .005f, .06f, .012f, 1f, .1f, .1f, 0f, 2f)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisableVertexAttribArray(1)
    }
}
